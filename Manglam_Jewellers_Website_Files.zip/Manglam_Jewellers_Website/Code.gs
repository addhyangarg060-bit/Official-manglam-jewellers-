/*
 * Manglam Jewellers backend — Google Apps Script
 * The shared admin password is stored server-side in this script, not in website files.
 * Change ADMIN_PASSWORD here if you ever want to rotate it.
 */
const ADMIN_PASSWORD = "octapr@9";
const DATA_KEY = "MANGLAM_SITE_DATA";
const TOKEN_PREFIX = "MJ_ADMIN_";
const TOKEN_TTL_SECONDS = 21600; // 6 hours

function doGet(e) {
  const action = (e && e.parameter && e.parameter.action) || "getData";
  if (action !== "getData") return json_({ok:false,error:"Unknown action"});
  const data = readData_();
  return json_({ok:true,rates:data.rates,products:data.products});
}

function doPost(e) {
  try {
    const body = JSON.parse((e && e.postData && e.postData.contents) || "{}");
    if (body.action === "login") {
      if (String(body.password || "") !== ADMIN_PASSWORD) return json_({ok:false,error:"Incorrect password"});
      const token = Utilities.getUuid() + Utilities.getUuid();
      CacheService.getScriptCache().put(TOKEN_PREFIX + token, "yes", TOKEN_TTL_SECONDS);
      return json_({ok:true,token:token});
    }
    requireAdmin_(body.token);
    const data = readData_();
    if (body.action === "saveRates") {
      const allowed = ["24k","22k","20k","18k","silver"];
      allowed.forEach(k => {
        const v = body.rates && body.rates[k] !== undefined ? String(body.rates[k]) : "";
        if (v !== "" && (!isFinite(Number(v)) || Number(v) < 0)) throw new Error("Please enter valid non-negative rates.");
        data.rates[k] = v;
      });
      data.rates.updatedAt = Utilities.formatDate(new Date(), Session.getScriptTimeZone(), "dd MMM yyyy, hh:mm a");
      saveData_(data);
      return json_({ok:true});
    }
    if (body.action === "addProduct") {
      const p = body.product || {};
      if (!p.name || !p.imageData) throw new Error("Product name and photo are required.");
      const match = String(p.imageData).match(/^data:(image\/(?:png|jpeg|webp|gif));base64,(.+)$/);
      if (!match) throw new Error("Please upload a JPG, PNG, WEBP or GIF image.");
      const bytes = Utilities.base64Decode(match[2]);
      if (bytes.length > 5 * 1024 * 1024) throw new Error("Image must be 5 MB or smaller.");
      const folder = getImageFolder_();
      const ext = match[1].split("/")[1].replace("jpeg","jpg");
      const blob = Utilities.newBlob(bytes, match[1], "manglam-product-" + new Date().getTime() + "." + ext);
      const file = folder.createFile(blob);
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      const product = {
        id: Utilities.getUuid(), name:String(p.name).slice(0,100), category:String(p.category||""),
        metal:String(p.metal||""), weight:String(p.weight||""), price:String(p.price||""),
        showPrice:!!p.showPrice, description:String(p.description||"").slice(0,250),
        imageUrl:"https://drive.google.com/uc?export=view&id="+file.getId(), driveFileId:file.getId()
      };
      data.products.unshift(product); saveData_(data);
      return json_({ok:true});
    }
    if (body.action === "deleteProduct") {
      const idx = data.products.findIndex(p => p.id === body.id);
      if (idx < 0) throw new Error("Product not found.");
      const p = data.products.splice(idx,1)[0];
      if (p.driveFileId) { try { DriveApp.getFileById(p.driveFileId).setTrashed(true); } catch(err) {} }
      saveData_(data);
      return json_({ok:true});
    }
    return json_({ok:false,error:"Unknown action"});
  } catch (err) {
    return json_({ok:false,error:err.message || String(err)});
  }
}

function requireAdmin_(token) {
  if (!token || CacheService.getScriptCache().get(TOKEN_PREFIX + token) !== "yes") {
    throw new Error("Admin session expired. Please log in again.");
  }
}
function readData_() {
  const raw = PropertiesService.getScriptProperties().getProperty(DATA_KEY);
  if (!raw) return {rates:{},products:[]};
  try { const d=JSON.parse(raw); return {rates:d.rates||{},products:d.products||[]}; }
  catch(e) { return {rates:{},products:[]}; }
}
function saveData_(data) {
  PropertiesService.getScriptProperties().setProperty(DATA_KEY, JSON.stringify(data));
}
function getImageFolder_() {
  const props=PropertiesService.getScriptProperties();
  let id=props.getProperty("MJ_IMAGE_FOLDER_ID");
  if (id) { try { return DriveApp.getFolderById(id); } catch(e) {} }
  const folder=DriveApp.createFolder("Manglam Jewellers Website Products");
  props.setProperty("MJ_IMAGE_FOLDER_ID",folder.getId());
  return folder;
}
function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}
