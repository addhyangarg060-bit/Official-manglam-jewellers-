// Manglam Jewellers frontend. Connect this page to the Google Apps Script URL in config.js.
const CONFIG = window.MANGLAM_CONFIG || {};
const API_URL = CONFIG.API_URL || "";
const DEFAULT_RATES = [
  {key:"24k",label:"24K Gold · 999",value:""},
  {key:"22k",label:"22K Gold · 916",value:""},
  {key:"20k",label:"20K Gold · 833",value:""},
  {key:"18k",label:"18K Gold · 750",value:""},
  {key:"silver",label:"Silver · 999",value:""}
];
let rates = {};
let products = [];
let adminToken = sessionStorage.getItem("mj_admin_token") || "";
const $ = id => document.getElementById(id);
const money = v => v === "" || v === null || v === undefined ? "—" : "₹" + Number(v).toLocaleString("en-IN", {maximumFractionDigits:2});
function toast(message){const el=$("toast");el.textContent=message;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2600)}
function apiPost(payload){
  if(!API_URL) return Promise.reject(new Error("Website backend is not connected yet. Follow SETUP-GUIDE.txt to connect it."));
  return fetch(API_URL,{method:"POST",headers:{"Content-Type":"text/plain;charset=utf-8"},body:JSON.stringify(payload)}).then(r=>r.json()).then(d=>{if(!d.ok)throw new Error(d.error||"Request failed");return d});
}
function apiGet(){
  if(!API_URL) return Promise.resolve(null);
  return fetch(API_URL+"?action=getData",{method:"GET"}).then(r=>r.json()).then(d=>d.ok?d:null).catch(()=>null);
}
function renderRates(){
  const grid=$("rateGrid");grid.innerHTML="";
  DEFAULT_RATES.forEach(item=>{
    const val=rates[item.key] ?? "";
    const card=document.createElement("article");card.className="rate-card"+(item.key==="silver"?" silver-card":"");
    card.innerHTML=`<span>${item.label}</span><strong>${money(val)}</strong><small>per gram</small><small>${val===""?"":money(Number(val)*10)+" per 10 grams"}</small>`;
    grid.appendChild(card);
  });
  $("updatedAt").textContent=rates.updatedAt ? "Last updated: "+rates.updatedAt : "Rates updated by Manglam Jewellers";
}
function renderProducts(category="All Products"){
  const grid=$("productGrid");grid.innerHTML="";
  const list=products.filter(p=>category==="All Products"||p.category===category);
  if(!list.length){grid.innerHTML='<div class="empty-state">No products in this category yet. Please check back soon.</div>';return}
  list.forEach(p=>{
    const card=document.createElement("article");card.className="product-card";
    const img=document.createElement("img");img.src=p.imageUrl||"";img.alt=p.name||"Jewellery";img.loading="lazy";
    const info=document.createElement("div");info.className="product-info";
    const h=document.createElement("h3");h.textContent=p.name||"Jewellery";
    const desc=document.createElement("p");desc.textContent=[p.metal,p.category,p.weight].filter(Boolean).join(" · ");
    info.append(h,desc);
    if(p.description){const d=document.createElement("p");d.textContent=p.description;info.append(d)}
    if(p.showPrice&&p.price){const price=document.createElement("p");price.className="price";price.textContent=money(p.price);info.append(price)}
    const ask=document.createElement("a");ask.className="button button-outline";ask.style.marginTop="8px";ask.textContent="Enquire on WhatsApp";ask.target="_blank";ask.rel="noopener";ask.href="https://wa.me/919891393189?text="+encodeURIComponent("Hello Manglam Jewellers, I am interested in "+p.name+". Please share details.");info.append(ask);
    card.append(img,info);grid.append(card);
  });
}
function renderAdminProducts(){
  const box=$("adminProductList");box.innerHTML="";
  products.forEach(p=>{
    const row=document.createElement("div");row.className="admin-product-row";
    const label=document.createElement("span");label.textContent=(p.name||"Product")+" · "+(p.category||"");
    const del=document.createElement("button");del.className="delete-btn";del.textContent="Delete";del.onclick=async()=>{if(!confirm("Delete "+(p.name||"this product")+"?"))return;try{await apiPost({action:"deleteProduct",token:adminToken,id:p.id});products=products.filter(x=>x.id!==p.id);renderProducts();renderAdminProducts();toast("Product deleted")}catch(e){toast(e.message)}};
    row.append(label,del);box.append(row);
  });
  if(!products.length)box.textContent="No products added yet.";
}
function renderAdminRates(){
  $("adminRateInputs").innerHTML="";
  DEFAULT_RATES.forEach(item=>{
    const wrap=document.createElement("label");wrap.textContent=item.label+" (per gram)";
    const input=document.createElement("input");input.type="number";input.min="0";input.step="0.01";input.id="rate_"+item.key;input.value=rates[item.key]??"";input.placeholder="Enter rate";
    wrap.append(input);$("adminRateInputs").append(wrap);
  });
}
async function loadData(){
  const data=await apiGet();
  if(data){rates=data.rates||{};products=data.products||[]}
  renderRates();renderProducts();renderAdminRates();
}
$("adminOpen").onclick=()=>$("adminDialog").showModal();
$("loginBtn").onclick=async()=>{
  $("loginError").textContent="";
  try{
    const result=await apiPost({action:"login",password:$("adminPassword").value});
    adminToken=result.token;sessionStorage.setItem("mj_admin_token",adminToken);
    $("loginPanel").hidden=true;$("adminPanel").hidden=false;
    await loadData();renderAdminProducts();toast("Admin access granted");
  }catch(e){$("loginError").textContent=e.message}
};
$("logoutBtn").onclick=()=>{adminToken="";sessionStorage.removeItem("mj_admin_token");$("adminPanel").hidden=true;$("loginPanel").hidden=false;$("adminPassword").value="";toast("Logged out")};
$("saveRates").onclick=async()=>{
  const newRates={};DEFAULT_RATES.forEach(x=>newRates[x.key]=$("rate_"+x.key).value);
  try{await apiPost({action:"saveRates",token:adminToken,rates:newRates});rates=newRates;rates.updatedAt=new Date().toLocaleString("en-IN");renderRates();toast("Rates saved successfully")}
  catch(e){toast(e.message)}
};
$("addProduct").onclick=async()=>{
  const file=$("pImage").files[0];if(!file){toast("Please choose a product photo");return}
  if(file.size>5*1024*1024){toast("Please choose an image smaller than 5 MB");return}
  const reader=new FileReader();reader.onload=async()=>{
    try{
      await apiPost({action:"addProduct",token:adminToken,product:{name:$("pName").value,category:$("pCategory").value,metal:$("pMetal").value,weight:$("pWeight").value,price:$("pPrice").value,showPrice:$("pShowPrice").checked,description:$("pDescription").value,imageData:reader.result}});
      $("pName").value="";$("pWeight").value="";$("pPrice").value="";$("pDescription").value="";$("pImage").value="";$("pShowPrice").checked=false;
      await loadData();renderAdminProducts();toast("Product uploaded");
    }catch(e){toast(e.message)}
  };reader.readAsDataURL(file);
};
document.querySelectorAll(".filter").forEach(btn=>btn.onclick=()=>{document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");renderProducts(btn.dataset.category)});
document.querySelectorAll(".tab").forEach(btn=>btn.onclick=()=>{document.querySelectorAll(".tab").forEach(b=>b.classList.remove("active"));btn.classList.add("active");$("rateEditor").hidden=btn.dataset.tab!=="rateEditor";$("productEditor").hidden=btn.dataset.tab!=="productEditor"});
$("langBtn").onclick=()=>{
  const hindi=$("langBtn").textContent==="हिंदी";
  document.querySelectorAll("[data-en]").forEach(el=>el.textContent=hindi?el.dataset.hi:el.dataset.en);
  $("langBtn").textContent=hindi?"English":"हिंदी";
};
$("year").textContent=new Date().getFullYear();
loadData();
